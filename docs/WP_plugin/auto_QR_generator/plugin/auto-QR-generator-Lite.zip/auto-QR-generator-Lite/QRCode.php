<?php

use Endroid\QrCode\Color\Color;
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\ErrorCorrectionLevel\ErrorCorrectionLevelLow;
use Endroid\QrCode\QrCode;
use Endroid\QrCode\RoundBlockSizeMode\RoundBlockSizeModeMargin;
use Endroid\QrCode\Writer\PngWriter;
use Endroid\QrCode\Logo\Logo;
use Endroid\QrCode\Label\Label;

function aqgl_QR_generation($url){

    $aqgl_logo_path = aqgl_check_logo_value();
    $aqgl_label = aqgl_check_label_value();

    if(!$url){
        $http = is_ssl() ? 'https' : 'http';
        $url = $http . '://' . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"];
    }

    $QRsize = !empty((int)get_option('QR_size')) ? (int)get_option('QR_size') : 200;
    $QRmargin = !empty((int)get_option('QR_margin')) ? (int)get_option('QR_margin') : 3;
    $logo_size = !empty((int)get_option('QR_logo_size')) ? (int)get_option('QR_logo_size') : 50;

    $QR_front_color_16 = get_option('QR_front_color');
    $front_color = aqgl_RGB_color($QR_front_color_16);
    $QR_BG_color_16 = get_option('QR_BG_color');
    $BG_color = aqgl_RGB_color($QR_BG_color_16);
    $label_color_16 = get_option('label_color');
    $label_color = aqgl_RGB_color($label_color_16);
    
    $writer = new PngWriter();

    // Create QR code
    $qrCode = QrCode::create($url)
        ->setEncoding(new Encoding('UTF-8'))
        ->setErrorCorrectionLevel(new ErrorCorrectionLevelLow())
        ->setSize($QRsize) /* size */
        ->setMargin($QRmargin) /* margin */
        ->setRoundBlockSizeMode(new RoundBlockSizeModeMargin())
        ->setForegroundColor(new Color($front_color[0], $front_color[1], $front_color[2])) /* Front Color */
        ->setBackgroundColor(new Color($BG_color[0], $BG_color[1], $BG_color[2])); /* BG color */

    //Logo setting
    if($aqgl_logo_path){
        $logo = Logo::create($aqgl_logo_path)
            ->setResizeToWidth($logo_size);
    }

    //Label setting
    if($aqgl_label){
        $label = Label::create($aqgl_label)
            ->setTextColor(new Color($label_color[0], $label_color[1], $label_color[2]));
    }

    $result = $writer->write($qrCode, $logo, $label);

    if($url === 'This QR code is perfect!'){
        $result->saveToFile(autoQRCodeGeneratorLite.'image/QRcode_sample.png');
    }

    $QRcode_url = $result->getDataUri();

    return $QRcode_url;
}