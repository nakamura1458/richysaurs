let QRsize = document.getElementById(`QR_size`);
let QRmargin = document.getElementById(`QR_margin`);
let frontColor = document.getElementById(`QR_front_color`);
let BGColor = document.getElementById(`QR_BG_color`);
let logosize = document.getElementById(`QR_logo_size`);
let labelcolor = document.getElementById(`label_color`);
let QRcode = document.getElementById(`QRcode_result`);

QRsize.addEventListener(`input`, () => {
	document.querySelector(`#QR_size2`).value = `${QRsize.value}`;
    console.log('Value (QR size) changed => ' + QRsize.value);
});

QRmargin.addEventListener(`input`, () => {
    document.querySelector(`#QR_margin2`).value = `${QRmargin.value}`;
    console.log('Value (QR margin) changed => ' + QRmargin.value);
});
	
frontColor.addEventListener(`input`, () => {
    document.querySelector(`#QR_front_color2`).value = `${frontColor.value}`;
    console.log('Value (front color) changed => ' + frontColor.value);
});

BGColor.addEventListener(`input`, () => {
    document.querySelector(`#QR_BG_color2`).value = `${BGColor.value}`;
    console.log('Value (BG color) changed => ' + BGColor.value);
});

logosize.addEventListener(`input`, () => {
    document.querySelector(`#QR_logo_size2`).value = `${logosize.value}`;
    console.log('Value (Logo size) changed => ' + logosize.value);
});

labelcolor.addEventListener(`input`, () => {
    document.querySelector(`#label_color2`).value = `${labelcolor.value}`;
    console.log('Value (Label Color) changed => ' + labelcolor.value);
});