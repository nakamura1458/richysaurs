<?php

class AQGL_QRcode_widget extends WP_Widget{

	//コンストラクタでウィジェットを登録
	function __construct(){
		parent::__construct(
			'aqgl_QR_add_settings',
			'2次元コードの表示',
			array('description' => '2次元コードを表示します。')
		);
	}

	//ウィジェットの表示
	public function widget($args, $instance){
		$url = home_url( '/' );
		$qrcode = aqgl_QR_generation($url);
		$alt = get_bloginfo('name');
		
		//-- ここにウィジェットの内容 --//
		$label = !empty($instance['aqgl_text']) ? $instance['aqgl_text'] : 'スマホで読み込む';
		$output = '<div style="text-align:center"><img src="'. $qrcode .'" name="aqgl_result" id="aqgl_result" alt="「'. esc_attr($alt) .'」の2次元コード" /></div>';
		
		if(is_home() || is_page() || is_category()){
			echo $args['before_widget'];
			echo $args['before_title']. $label . $args['after_title'];
			echo $output;
			echo $args['after_widget'];
		}

	}

	//ウィジェットフォームの作成
	public function form($instance){
		$text = !empty($instance['aqgl_text']) ? $instance['aqgl_text'] : 'スマホで読み込む';
		$url = home_url( '/' );
		$qrcode = aqgl_QR_generation($url);
		?>
		<h2>2次元コードの設定</h2>
		<p>2次元コードの上に表示するテキストを設定します。<br>
		<label for="<?php echo $this->get_field_id('aqgl_text'); ?>">テキスト</label><br>
		<input id="<?php echo $this->get_field_id('aqgl_text'); ?>" name="<?php echo $this->get_field_name('aqgl_text'); ?>" type="text" value="<?php echo esc_attr($text); ?>" placeholder="スマホで読み込む">
		</p>
		<br>
		<h2>2次元コードサンプル</h2>
		<p>この2次元コードは、固定ページ、トップページでのみ表示されます</p>
		<div style="text-align:center">
			<img src="<?php echo esc_attr($qrcode) ?>" id="changed" name="changed" alt="2次元コードのサンプル" >
		</div>
		<br>
		<?php
	}

	//入力されたデータの更新処理
	//	new_instance：更新後の値
	//	old_instance：更新前の値
	public function update($new_instance, $old_instance){
		$instance = array();
		$instance['aqgl_text'] = !empty($new_instance['aqgl_text']) ? $new_instance['aqgl_text'] : 'スマホで読み込む';
		
		return $instance;	//更新されたデータが入った配列を戻り値として返す
	}
}

add_action(
	'widgets_init',
	function(){
		register_widget('AQGL_QRcode_widget');	//パラメータなし
	}
);