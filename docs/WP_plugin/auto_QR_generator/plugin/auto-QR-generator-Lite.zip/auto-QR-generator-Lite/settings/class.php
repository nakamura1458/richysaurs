<?php

function aqgl_init_option(){
    //初期化の処理を行う
    if(!get_option('aqgl_installed')){
        add_option('aqgl_installed', 1);
        add_option('logo_set', '');
        add_option('QR_logo_image', '');
        add_option('QR_size', '');
        add_option('label_set', '');
        add_option('QR_margin', '');
        add_option('QR_logo_size', '');
        add_option('label', '');
        add_option('QR_front_color', '');
        add_option('QR_BG_color', '');
        add_option('label_color', '');
    }
}
register_activation_hook(__FILE__, 'aqgl_init_option');

function aqgl_checkbox_checked($val){
    if((int)$val === 1){
        echo ' checked="checked"';
    }
}

function aqgl_checkbox($name, $label){
    $value = (int)get_option($name);
    ?>
    <label><?php echo esc_html($label) ?></label>
    <input type="checkbox" name="<?php echo esc_attr($name); ?>" value="1"<?php aqgl_checkbox_checked($value); ?> />
    <?php
}

function aqgl_form_normal($label, $size, $id, $place){
    ?>
    <table class="form-table">
        <tr valign="top">
            <th scope="row"><label><?php echo esc_html($label) ?></label></th>
            <td><input type="text" size="<?php echo esc_attr($size) ?>" name="<?php echo esc_attr($id) ?>" id="<?php echo esc_attr($id) ?>" value="<?php echo esc_attr(get_option($id)); ?>" placeholder="<?php echo esc_attr($place) ?>"></td>
        </tr>
    </table>
    <?php
}

function aqgl_select_number($name, $max, $label){
    $value = (int)get_option($name);
    ?>
    <select name="<?php echo esc_attr($name) ?>" id="<?php echo esc_attr($name) ?>">
        <option value="0" <?php if(!empty($value)){if($value === 0){echo 'selected'; } } ?>>未選択</option>
        <?php
        for((int)$i=1; $i<=$max; $i++){
        ?>
        <option value="<?php echo esc_attr($i) ?>" <?php if(!empty($value)){if($value === $i){echo 'selected'; } } ?>><?php echo esc_html($label[$i-1]) ?></option>
        <?php
        }
        ?>
    </select>
    <?php
}

function aqgl_RGB_color($color){
    $red_16 = substr($color, 1, 2);
    $green_16 = substr($color, 3, 2);
    $blue_16 = substr($color, 5, 2);

    $red = (int)hexdec ( $red_16 );
    $green = (int)hexdec ( $green_16 );
    $blue = (int)hexdec ( $blue_16 );

    $result = array($red, $green, $blue);

    return $result;
}

function aqgl_color_check($init, $val){
    if(!$val){
        echo esc_attr($init);
    }else{
        echo esc_attr($val);
    }
}

function aqgl_check_logo_value(){
    
    $image = get_option('QR_logo_image');
    $size = (int)get_option('QR_logo_size');
    $check = (int)get_option('logo_set');
    $resize = autoQRCodeGeneratorLite.'image/QRLogo_resize.png';

    if($check === 1){
        if(!$image){
            $image = get_site_icon_url();
        }
        $logo = aqgl_resize_image($image, $resize, $size);
        return $logo;
    }else{
        return '';
    }

}

function aqgl_check_label_value(){
    $check = (int)get_option('label_set');
    $label = get_option('label');

    if($check === 1){
        return $label;
    }else{
        return '';
    }
}

function aqgl_auto_make_QRCode(){
	$http = is_ssl() ? 'https' : 'http';
    $url = $http . '://' . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"];
    $result = aqgl_QR_generation($url);
    $alt = get_the_title();
 	?>
 	<script>
 		const result = '<?=$result?>';
		const url = '<?=$url?>';
        const alt = '<?=$alt?>';
        document.addEventListener('DOMContentLoaded', (event) => {
            const element = document.getElementById('aqgl_result')
			element.src = result;
            element.alt = alt;
			console.log('This page is "' + url + '" / Page name is "' + alt + '"');
        });
 	</script>
 	<?php
}
add_action('wp_head', 'aqgl_auto_make_QRCode');

function aqgl_add_files(){
    wp_enqueue_style('aqgl_error_messages', autoQRCodeGeneratorLite_url.'src/css/error_message.css');
    wp_enqueue_style('aqgl_form_css', autoQRCodeGeneratorLite_url.'src/css/range_bar.css');
    wp_enqueue_script('aqgl_range_bar_script', autoQRCodeGeneratorLite_url.'/src/js/rangebar.js?ver='.time(), '', '', true);
}
add_action('admin_enqueue_scripts', 'aqgl_add_files');