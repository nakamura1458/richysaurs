<?php

//---- 管理画面にプラグインページを設定 ----//
function aqgl_add_main_setting_page(){
    //メインメニュー
    add_menu_page(
        'Auto QR Generator',
        'QRコードの設定',
        'manage_options',
        'aqgl_setting',
        'aqgl_make_QR',
        'dashicons-screenoptions'
    );

}

add_action('admin_menu', 'aqgl_add_main_setting_page');