<?php

function aqgl_make_QR(){

    if($_POST['QR_setting'] === 'save'){
        $logo_set = absint($_POST['logo_set']);
        update_option('logo_set', $logo_set);
        $label_set = absint($_POST['label_set']);
        update_option('label_set', $label_set);
        $QRlogo = sanitize_url($_POST['QR_logo_image']);
        update_option('QR_logo_image', $QRlogo);
        $qrsize = absint($_POST['QR_size']);
        update_option('QR_size', $qrsize);
        $margin = absint($_POST['QR_margin']);
        update_option('QR_margin', $margin);
        $logoS = absint($_POST['QR_logo_size']);
        update_option('QR_logo_size', $logoS);
        $Lab = sanitize_text_field($_POST['label']);
        update_option('label', $Lab);
        $FR = sanitize_text_field($_POST['QR_front_color']);
        update_option('QR_front_color', $FR);
        $BG = sanitize_text_field($_POST['QR_BG_color']);
        update_option('QR_BG_color', $BG);
        $LC = sanitize_text_field($_POST['label_color']);
        update_option('label_color', $LC);
    }

    $QRsize = !empty((int)get_option('QR_size')) ? (int)get_option('QR_size') : 200;
    $QRmargin = !empty((int)get_option('QR_margin')) ? (int)get_option('QR_margin') : 3;
    $logo_size = !empty((int)get_option('QR_logo_size')) ? (int)get_option('QR_logo_size') : 50;

    $image = get_option('QR_logo_image');
    $aqgl_label = get_option('label');
    $QR_front_color_16 = get_option('QR_front_color');
    $QR_BG_color_16 = get_option('QR_BG_color');
    $label_color_16 = get_option('label_color');

    if($_POST['QR_setting'] === 'save'){ ?><div class="updated"><p><b>設定を保存しました</b></p></div><?php } ?>

    <h1>2次元コードの設定</h1>
    <form method="post" action="<?php echo str_replace( '%7E', '~', esc_html($_SERVER['REQUEST_URI'])); ?>">
    <p>当プラグインで設置する2次元コードの設定を行います。<br>
    このページで設定された内容が全ページに適応されます。</p>
    <br>

    <h2>2次元コードの詳細</h2>
    <p>2次元コードの詳細設定を行います。<br>設定は下記の写真を参考にしてください。</p>
    <img src = "<?php echo esc_attr(autoQRCodeGeneratorLite_url).'image/QR_sample_description.png' ?>" class="qr_sample" alt="2次元コードの説明画像" >
    <br>

    <p>
        <div>
            <label>2次元コードのサイズ</label><br>
            200px<input type="range" name="QR_size" class="aqgl_range" id="QR_size" min="200" max="500" step="10" value="<?php echo esc_attr($QRsize) ?>" >500px 
            <input type="text" id="QR_size2" class="size_form" value="<?php echo esc_attr($QRsize) ?>" readonly >px
        </div>
    </p>
    <br>

    <p>
        <div>
            <label>余白の大きさ</label><br>
            3px<input type="range" name="QR_margin" id="QR_margin" class="aqgl_range" min="3" max="15" step="1" value="<?php echo esc_attr($QRmargin) ?>" >15px
            <input type="text" id="QR_margin2" class="size_form" value="<?php echo esc_attr($QRmargin) ?>" readonly >px
        </div>
    </p>
    <br>    

    <table class="aqgl_table">
        <tr>
            <th><label>2次元コードの色</label></th>
            <th><label>背景の色</label></th>
        </tr>
        <tr>
            <td>
                <div style="text-align:center">
                    <input type="color" id="QR_front_color" class="aqgl_range_color" name="QR_front_color" value="<?php aqgl_color_check('#000000', $QR_front_color_16); ?>" >
                    <input type="text" id="QR_front_color2" class="color_form" value="<?php aqgl_color_check('#000000', $QR_front_color_16); ?>" readonly >
                </div>
            </td>
            <td>
                <div style="text-align:center">
                    <input type="color" id="QR_BG_color" class="aqgl_range_color" name="QR_BG_color" value="<?php aqgl_color_check('#ffffff', $QR_BG_color_16); ?>" >
                    <input type="text" id="QR_BG_color2" class="color_form" value="<?php aqgl_color_check('#ffffff', $QR_BG_color_16); ?>" readonly >
                </div>
            </td>
        </tr>
    </table>

    <h2>ロゴの挿入</h2>
    <p>2次元コードの中心に画像を挿入する場合は、下記のチェックボックスにチェックを入れてください。</p>
	<?php aqgl_checkbox('logo_set', 'ロゴ画像を設置する') ?>
    <br>

    <?php
    if((int)get_option('logo_set') === 1){
        ?>

        <h3>ロゴ画像のサイズ</h3>
        <p>ロゴ画像のサイズを選択してください。<br>
        ロゴ画像のサイズを大きくしすぎると、2次元コードを読み込めない、またはロゴ画像が透けてしまう場合があります</p>
        <p>
            <div>
                <label>ロゴ画像のサイズ</label><br>
                50px<input type="range" name="QR_logo_size" id="QR_logo_size" class="aqgl_range" min="50" max="85" step="1" value="<?php echo esc_attr($logo_size) ?>" >85px
                <input type="text" id="QR_logo_size2" class="size_form" value="<?php echo esc_attr($logo_size) ?>" readonly >px
            </div>
        </p>
            
        <br>

        <h3>ロゴ画像を選択</h3>
        <p>2次元コードの中心に表示する画像を設定します。<br>
        画像の拡張子は、<b>gif、jpeg(jpg)、png</b>に限ります。<br>
        また、この項目が空欄の場合には、ファビコンを使用します（ファビコンが上記の画像の種類以外の場合は設定されません）。</p>
        <?php
        aqgl_form_normal('画像URL', 100, 'QR_logo_image', '画像URLを入力');
    }
    ?>

    <h2>ラベルの挿入</h2>
    <p>2次元コードの下にラベルを挿入する場合は、下記のチェックボックスにチェックを入れてください。</p>
	<?php aqgl_checkbox('label_set', 'ラベルを設置する') ?>
    <br>

    <?php
    if((int)get_option('label_set') === 1){ ?>

        <h3>ラベルを入力</h3>
        <p>2次元コードの下に表示するラベルを設定します。<br>
        表示したいラベルを入力してください。</p>
        <?php aqgl_form_normal('ラベル', 100, 'label', 'ラベルを入力'); ?>

        <h3>ラベルの色</h3>
        <p>ラベルの色を選択してください。<br>
        デフォルトでは黒に設定されています。</p>
        <p>
            <div>
                <label>ラベルテキストの色</label><br>
                <input type="color" id="label_color" class="aqgl_range_color" name="label_color" value="<?php aqgl_color_check('#ffffff', $label_color_16); ?>" >
                <input type="text" id="label_color2" class="color_form" value="<?php aqgl_color_check('#ffffff', $label_color_16); ?>" readonly >
            </div>
        </p>
        <br>
        <?php
    }
    ?>

    <input type="hidden" name="QR_setting" value="save">
    <input type="submit" name="submit" value="設定を保存する">
    </form>

    <?php
    $url = 'This QR code is perfect!';
    $qrcode = aqgl_QR_generation($url);

    ?>
    <h2>2次元コードの表示例</h2>
    <p>作成した2次元コードの例がこちらです。<br>
    スマホなどで2次元コードを読み取り、「This QR code is perfect!」と表示されればOKです。<br>
    表示されない場合には、2次元コードの大きさや色、ロゴのサイズなどを設定し直してください。</p>
    <img src="<?php echo esc_attr(autoQRCodeGeneratorLite_url.'image/QRcode_sample.png') ?>" name="qr_sample_result" id="qr_sample_result" alt="2次元コードの例" />

    <script>
 		const result_sample = '<?=$qrcode?>';
 		window.onload = function(){
			const elem = document.getElementById('qr_sample_result')
			elem.src = result_sample;
			console.log('Change the QRcode!');
 		}
 	</script>

    <?php
}