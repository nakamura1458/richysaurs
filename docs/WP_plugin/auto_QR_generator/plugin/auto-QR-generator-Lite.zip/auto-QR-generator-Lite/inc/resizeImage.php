<?php

function aqgl_resize_image($image, $imageAfter, $size){

    $headers = @get_headers( $image );
	if( !preg_match( '/[2][0-9][0-9]|[3][0-9][0-9]/', $headers[0] ) ){
		echo '<p class="aqgl_error"><b>URLが存在しません</b></p>';
		return '';
	}
	
	if(@is_array(getimagesize($image)) === false){
		echo '<p class="aqgl_error"><b>画像URLではありません</b></p>';
		return '';
	}
    
    list($src_w, $src_h, $type) = getimagesize($image);

    switch($type){
        case IMAGETYPE_JPEG:
            $image_copy = imagecreatefromjpeg($image);
            break;
        case IMAGETYPE_GIF:
            $image_copy = imagecreatefromgif($image);
            break;
        case IMAGETYPE_PNG:
            $image_copy = imagecreatefrompng($image);
            break;
        default:
            echo '<p class="aqgl_error"><b>対応していない画像形式です。png、jpeg(jpg)、gifのいずれかの形式の画像をお使いください</b></p>';
            return '';
    }

    // コピー先画像作成
    $dst_image = imagecreate($size, $size);

    imagecopyresampled(
        $dst_image, // コピー先の画像
        $image_copy, // コピー元の画像
        0,          // コピー先の x 座標
        0,          // コピー先の y 座標。
        0,          // コピー元の x 座標
        0,          // コピー元の y 座標
        $size,     // コピー先の幅
        $size,     // コピー先の高さ
        $src_w,     // コピー元の幅
        $src_h      // コピー元の高さ
    );    
        
    // 画像をファイルに出力
    imagepng($dst_image, $imageAfter);

    return $imageAfter;

}