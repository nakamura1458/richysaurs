=== auto QR Generator Lite ===
Contributors: nakamura1458
Tags: QR code, SEO, auto setting
Requires at least: 5.7
Tested up to: 6.0.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Requires PHP: 7.0

This plugin makes QR code automatically!

== Description ==

This plugin makes the QR code automatically.
Also, you can choose the where to place the QR code from the widget settings.

You can set the following items.

* size of the QR code
* margin
* color of the QR code
* color of the background color
* logo image and size (optional)
* label text and color (optional)

In order to use this plugin, you must purchase the right to use the plugin.
You can purchase the right here.
(note link)

With a relatively simple initial setup, all pages automatically output the QR code per page.
For more information on setting up plug-ins, please check this page.
(https://richynokurashi.com/lp/aqg_setting/)


== Installation ==

1. Download the plugin from this page (https://richynokurashi.com/lp/aqg_setting/).
2. Save the .zip file to a location on your computer.
3. Open the WP admin panel, and click “Plugins” -> “Add new”.
4. Click “upload”.. then browse to the .zip file downloaded from this page.
5. Click “Install”.. and then “Activate plugin”.


== Frequently asked questions ==



== Changelog ==



== Upgrade notice ==


== Arbitrary section 1 ==