<?php
/**
 * Plugin Name: auto QR Generator Lite
 * Plugin URI: https://richynokurashi.com/lp/aqg_lite/
 * Description: 2次元コードを自動生成します
 * Version: 1.0
 * Author: リッチー
 * Author URI:  https://richynokurashi.com
 */

define('autoQRCodeGeneratorLite', plugin_dir_path(__FILE__));
define('autoQRCodeGeneratorLite_url', plugin_dir_url(__FILE__));

require_once(plugin_dir_path(__FILE__) .'vendor/autoload.php');
require_once(plugin_dir_path(__FILE__).'settings/class.php');
require_once(plugin_dir_path(__FILE__).'settings/admin_page.php');
require_once(plugin_dir_path(__FILE__).'inc/resizeImage.php');
require_once(plugin_dir_path(__FILE__).'settings/setting_page.php');
require_once(plugin_dir_path(__FILE__).'settings/widget.php');
require_once(plugin_dir_path(__FILE__).'QRCode.php');

add_action('wp_enqueue_scripts', 'aqgl_add_files');